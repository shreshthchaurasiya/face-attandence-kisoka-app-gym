<?php
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];

// GET Attendance Logs
if ($method === 'GET') {
    $date = isset($_GET['date']) ? trim($_GET['date']) : date('Y-m-d');

    $stmt = $pdo->prepare("
        SELECT a.id, a.profile_id, a.profile_name, a.profile_type, a.log_date, a.check_in_time, a.check_out_time, a.method, a.created_at,
               p.role, p.phone, p.profile_code
        FROM attendance_logs a
        LEFT JOIN profiles p ON a.profile_id = p.id
        WHERE a.log_date = ?
        ORDER BY a.check_in_time DESC
    ");
    $stmt->execute([$date]);
    $logs = $stmt->fetchAll();

    echo json_encode([
        'status' => 'success',
        'date' => $date,
        'count' => count($logs),
        'data' => $logs
    ]);
    exit();
}

// POST: Mark Check-In or Check-Out
if ($method === 'POST') {
    $input = getJsonInput();
    $profileId = isset($input['profile_id']) ? intval($input['profile_id']) : 0;
    $methodType = isset($input['method']) ? trim($input['method']) : 'face_kiosk';

    if (!$profileId) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Profile ID is required']);
        exit();
    }

    // Verify profile exists
    $stmt = $pdo->prepare("SELECT id, name, type, role, status FROM profiles WHERE id = ?");
    $stmt->execute([$profileId]);
    $profile = $stmt->fetch();

    if (!$profile) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Profile not found']);
        exit();
    }

    if ($profile['status'] !== 'active') {
        http_response_code(403);
        echo json_encode([
            'status' => 'error',
            'action' => 'denied',
            'message' => 'Profile is inactive'
        ]);
        exit();
    }

    $today = date('Y-m-d');
    $currentTime = date('H:i:s');

    // Check if already checked in today
    $checkStmt = $pdo->prepare("SELECT id, check_in_time, check_out_time FROM attendance_logs WHERE profile_id = ? AND log_date = ?");
    $checkStmt->execute([$profileId, $today]);
    $existing = $checkStmt->fetch();

    if ($existing) {
        // Already checked in today. Option: Update check_out_time if requested, or report already in
        $action = isset($input['action']) ? $input['action'] : 'check_in';
        if ($action === 'check_out') {
            $upd = $pdo->prepare("UPDATE attendance_logs SET check_out_time = ? WHERE id = ?");
            $upd->execute([$currentTime, $existing['id']]);
            echo json_encode([
                'status' => 'success',
                'action' => 'checked_out',
                'message' => "Goodbye {$profile['name']}! Check-out logged.",
                'check_out_time' => $currentTime
            ]);
            exit();
        }

        echo json_encode([
            'status' => 'warning',
            'action' => 'already_in',
            'message' => "Already checked in at {$existing['check_in_time']}",
            'data' => $existing
        ]);
        exit();
    }

    // Insert new check-in
    $insertStmt = $pdo->prepare("
        INSERT INTO attendance_logs (`profile_id`, `profile_name`, `profile_type`, `log_date`, `check_in_time`, `method`)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $insertStmt->execute([
        $profile['id'],
        $profile['name'],
        $profile['type'],
        $today,
        $currentTime,
        $methodType
    ]);

    echo json_encode([
        'status' => 'success',
        'action' => 'checked_in',
        'message' => "Welcome to Panda Ka Dhaba, {$profile['name']}!",
        'data' => [
            'id' => $pdo->lastInsertId(),
            'name' => $profile['name'],
            'role' => $profile['role'],
            'check_in_time' => $currentTime,
            'log_date' => $today
        ]
    ]);
    exit();
}
